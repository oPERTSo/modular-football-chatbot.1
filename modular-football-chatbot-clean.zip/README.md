# 🏆 Modular Football Chatbot

## 📋 คำอธิบาย
ระบบ AI วิเคราะห์ฟุตบอลแบบ Modular ที่แยกฟังก์ชันการทำงานออกเป็นส่วนๆ พร้อมฟีเจอร์ Live Features

## 🚀 ฟีเจอร์หลัก
- 🔥 Live Match API - ข้อมูลแมทช์สด
- 📊 Player Statistics API - สถิติผู้เล่น  
- 📰 Transfer News API - ข่าวซื้อขาย
- 🤖 OpenAI GPT Integration - AI ตอบคำถาม
- 🧪 Complete Test Suite - ชุดทดสอบครบถ้วน

## 🛠️ การติดตั้ง

### 1. Clone หรือ Download โปรเจค
```bash
git clone <your-repo-url>
cd modular-football-chatbot
```

### 2. ติดตั้ง Dependencies
```bash
pip install -r requirements.txt
```

### 3. ตั้งค่า API Keys
```bash
# Copy template file
cp .env .env.local

# แก้ไขไฟล์ .env.local ใส่ API keys ของคุณ
# OPENAI_API_KEY=sk-your-actual-key
# API_FOOTBALL_KEY=your-actual-key
```

### 4. รันโปรเจค
```bash
python app.py
```

## 📁 โครงสร้างโปรเจค
```
├── app.py                 # Main Flask application
├── modules/               # โมดูลหลักของระบบ
│   ├── api_handlers.py    # จัดการ API endpoints
│   ├── live_extensions.py # Live features APIs
│   └── ...
├── live_features_test/    # ชุดทดสอบ Live Features
├── templates/             # HTML templates
├── static/               # CSS, JS files
├── data/                 # ข้อมูลอ้างอิง
└── requirements.txt      # Python dependencies
```

## 🔧 การใช้งาน

### เข้าใช้งานผ่านเว็บ
- หน้าแรก: http://localhost:5000
- หน้าแชท: http://localhost:5000/chat-ui

### API Endpoints
- `/api/standings` - ตารางคะแนน
- `/api/topscorers` - ดาวซัลโว  
- `/api/news` - ข่าวฟุตบอล
- `/chat` - แชทกับ AI

## 🧪 การทดสอบ
```bash
# ทดสอบ Live Features
cd live_features_test
python quick_test.py

# ทดสอบ Integration
python integration_test.py
```

## 🔒 ความปลอดภัย
- ไฟล์ `.env` มีเฉพาะ placeholders
- ใช้ `.env.local` สำหรับ API keys จริง
- `.env.local` ไม่ถูก commit ลง Git

## 📞 การช่วยเหลือ
หากมีปัญหาการใช้งาน ให้ดูไฟล์ `SETUP.md` สำหรับคำแนะนำเพิ่มเติม

## 🎯 สถานะ
✅ ใช้งานได้ 100%  
✅ ทดสอบครบถ้วน  
✅ พร้อม Deploy
