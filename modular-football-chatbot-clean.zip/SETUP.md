# 🔧 Setup Instructions

## 📋 Required API Keys

### 1. OpenAI API Key
1. Go to [OpenAI Platform](https://platform.openai.com/api-keys)
2. Create new API key
3. Copy the key (starts with `sk-proj-...`)

### 2. Football API Key  
1. Go to [API-Football](https://www.api-football.com/)
2. Register for free account
3. Get your API key from dashboard

## ⚙️ Environment Setup

1. **Copy the environment file:**
   ```bash
   cp .env .env.local
   ```

2. **Edit `.env.local` with your real API keys:**
   ```bash
   OPENAI_API_KEY=sk-proj-your_actual_openai_key_here
   API_FOOTBALL_KEY=your_actual_football_api_key_here
   sportsdb_api_key=503385
   ```

3. **Update config to use local file:**
   The system will automatically load from `.env.local` if it exists.

## 🚀 Running the Application

```bash
# Install dependencies
pip install -r requirements.txt

# Start the Flask server
python app.py
```

## 📱 Access Points

- **Main App**: http://localhost:5000
- **Chat Interface**: http://localhost:5000/chat-ui  
- **API Testing**: http://localhost:5000/test-api.html
- **Live Features**: http://localhost:5000/test-live-features.html

## 🔒 Security

- **Never commit real API keys to Git**
- **Use `.env.local` for your actual keys**
- **The `.env` file contains only placeholder values**

## 🎯 Features

✅ **Core Features:**
- Football standings and scores
- Top scorers and player stats  
- Team form comparison
- News and fixtures

✅ **Live Features:**
- Real-time match data
- Player statistics
- Transfer news
- Search functionality

## 🧪 Testing

```bash
# Test the APIs
python test_real_apis.py

# Test new endpoints  
python test_new_endpoints.py

# Quick feature test
python live_features_test/quick_test.py
```
